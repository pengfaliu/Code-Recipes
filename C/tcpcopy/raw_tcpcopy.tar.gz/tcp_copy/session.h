/*
 * =====================================================================================
 *
 *       Filename:  session.h
 *       Compiler:  g++
 *
 *         Author:  wangbo@corp.netease.com
 *
 *      CopyRight:  Copyright (c) netease
 *
 *    Description:  
 *
 *        Created:  2009-09-10 16:48:06
 * =====================================================================================
 */


#ifndef  _TCP_REDIRECT_SESSION_H__INC
#define  _TCP_REDIRECT_SESSION_H__INC

#include <sys/types.h>
#include <stdio.h>
#include <idn-int.h> 
#include<netinet/ip.h>
#include<netinet/tcp.h>
#include<stdlib.h>
#include "header.h"
#include <list>

extern uint32_t local_ip;
extern uint32_t remote_ip;
extern uint16_t local_port;
extern uint16_t remote_port;

#pragma pack(push,1)
struct etharp_frame { 
	unsigned char dst[6]; 
	unsigned char src[6];
	unsigned short type; 
};
#pragma pack(pop)
void process(char *,int);

typedef std::list<unsigned char *> dataContainer;
typedef std::list<unsigned char *>::iterator dataIterator;


struct session_st
{
	//uint32_t real_sequence;
	uint32_t virtual_next_sequence;
	uint32_t virtual_ack;
	//time_t   last_time;
	uint16_t virtual_status;
	//uint16_t real_status;

	uint32_t client_next_sequence;
	uint16_t client_window;
	uint16_t client_ip_id ;
	unsigned char *fin_ack_package;

	bool     confirmed;
	bool     reset_flag;
	dataContainer unsend;
	session_st()
	{
		virtual_status = SYN_SEND;
		virtual_next_sequence=0;
		fin_ack_package = NULL;
		confirmed = false;
		reset_flag = false;
	}
	~session_st()
	{
		free(fin_ack_package);
		for(dataIterator iter=unsend.begin();iter!=unsend.end();iter++)
		{
			free(*iter);
		}
	}
	void send_fake_ack(uint32_t s_ip,uint16_t s_port);
	void update_virtual_status(struct iphdr *ip_header,struct tcphdr* tcp_header);
	unsigned char * copy_ip_package(struct iphdr *ip_header);
	void save_header_info(struct iphdr *ip_header,struct tcphdr *tcp_header);
	void process_recv(struct iphdr *ip_header,struct tcphdr *tcp_header);
	bool is_over()
	{
		if( (virtual_status&CLIENT_FIN) && (virtual_status&SERVER_FIN) && confirmed)
		{
			return true;
		}
		if(reset_flag)
		{
			return true;
		}
		return false;
	}
};


inline uint64_t get_ip_port_value(uint32_t s_ip,uint16_t s_port)
{
	return uint64_t(s_ip)*65535+s_port;
}

#endif   /* ----- #ifndef _TCP_REDIRECT_SESSION_H__INC  ----- */
