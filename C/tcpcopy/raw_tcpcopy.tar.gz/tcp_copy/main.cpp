/*
 * =====================================================================================
 *
 *       Filename:  tcp_redirect.cpp
 *       Compiler:  g++
 *
 *         Author:  wangbo@corp.netease.com
 *
 *      CopyRight:  Copyright (c) netease
 *
 *    Description:  
 *
 *        Created:  2009-09-09 17:22:07
 * =====================================================================================
 */

#include<errno.h>
#include<stdlib.h>
#include<string.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<netinet/ether.h>

#include "session.h"
#include "send.h"

#define MAX_IP_LEN 65536


/*int set_filiter(pcap_t *fp)
{
	char *filter = "src 61.135.250.217";
	struct bpf_program fcode;
	if(pcap_compile(fp, &fcode, filter, 0, 0) < 0) 
	{
		fprintf(stderr,"\nError compiling filter: wrong syntax.%s\n",pcap_geterr(fp)); 
		return -1; 
	}
	if(pcap_setfilter(fp, &fcode) <0) 
	{ 
		fprintf(stderr,"\nError setting the filter%s\n",pcap_geterr(fp)); 
		return -2; 
	} 
}*/

char recvbuf[65535];
int main(int argc ,char **argv)
{
	if(argc != 5)
	{
		printf("Usage: %s 61.135.250.201 80 61.135.250.217 80\n\n");
		exit(1);
	}
	local_ip = inet_addr(argv[1]);
	local_port = htons(atoi(argv[2]));
	remote_ip = inet_addr(argv[3]);
	remote_port = htons(atoi(argv[4]));

	printf("%x %d %x %d\n",local_ip,local_port,remote_ip,remote_port);
	
	int sock = socket(AF_PACKET,SOCK_RAW,htons(ETH_P_ALL));
	if(!sock)
	{
		perror("socket");
	}
	send_init();
	while(1)
	{
		int recv_len = recvfrom(sock,recvbuf,2000,0,NULL,NULL);
		process(recvbuf,recv_len);
	}
	return 0;
}




