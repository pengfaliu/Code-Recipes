/*
 * =====================================================================================
 *
 *       Filename:  send.cpp
 *       Compiler:  g++
 *
 *         Author:  wangbo@corp.netease.com
 *
 *      CopyRight:  Copyright (c) netease
 *
 *    Description:  
 *
 *        Created:  2009-09-09 19:43:39
 * =====================================================================================
 */

#include <string.h>
#include "header.h"
#include "session.h"

static int sock;
static struct sockaddr_in toaddr;

static int modify_init()
{
	unsigned short *l_ip_1 = (unsigned short *)&local_ip;
	unsigned short *l_ip_2 = l_ip_1+1;
	unsigned short *r_ip_1 = (unsigned short *)&remote_ip;
	unsigned short *r_ip_2 = r_ip_1+1;
	//tcp_checksum_value = *r_ip_1+*r_ip_2-l_ip_1-l_ip_2;
}
static void tcp_modify_checksum(struct tcphdr *tcp_header)
{
}
static int ip_modify_checksum()
{
}


int send_init()
{
	sock = socket(AF_INET, SOCK_RAW,IPPROTO_RAW);
	if (sock>0) 
	{
		printf("socket ok\n");
	} 
	else 
	{
		printf ("socket error \n");
	} 
	int n=1; 
	if (setsockopt(sock, IPPROTO_IP, IP_HDRINCL, &n, sizeof(n)) < 0) {  
		perror("IP_HDRINCL");  
		exit(1);  
	} 
	toaddr.sin_family = AF_INET;
	toaddr.sin_addr.s_addr = remote_ip;
}


static unsigned short csum (unsigned short *packet, int packlen) 
{ 
	register unsigned long sum = 0; 
	while (packlen > 1) {
		sum+= *(packet++); 
		packlen-=2; 
	} 
	if (packlen > 0) 
		sum += *(unsigned char *)packet; 
	while (sum >> 16) 
		sum = (sum & 0xffff) + (sum >> 16); 
	return (unsigned short) ~sum; 
} 

static unsigned short buf[2000]; 
static unsigned short tcpcsum(unsigned char *iphdr,unsigned short *packet,int packlen) 
{ 
	unsigned short res; 
	memcpy(buf,iphdr+12,8); //ԴIP��ַ��Ŀ��IP��ַ 
	*(buf+4)=htons((unsigned short)(*(iphdr+9))); 
	*(buf+5)=htons((unsigned short)packlen); 
	memcpy(buf+6,packet,packlen); 
	res = csum(buf,packlen+12); 
	return res; 
} 

uint32_t send_ip_package(unsigned char *data,uint32_t ack_seq)
{
	if(! data)
	{
		return 0;
	}
	struct iphdr *ip_header = (struct iphdr *)data;
	uint32_t size_ip = ip_header->ihl*4;
	struct tcphdr *tcp_header = (struct tcphdr *)(data+size_ip);
	tcp_header->dest = remote_port;
	ip_header->daddr = remote_ip;
	if(tcp_header->ack)
	{
		tcp_header->ack_seq = ack_seq;
	}
	tcp_header->check = 0;
	uint16_t tot_len  = ntohs(ip_header->tot_len);
	tcp_header->check = tcpcsum((unsigned char *)ip_header,(unsigned short *)tcp_header,tot_len-size_ip);
	ip_header->check = 0;
	ip_header->check = csum((unsigned short *)ip_header,size_ip); 
	int send_len = sendto(sock,(char *)ip_header,tot_len,0,(struct sockaddr *)&toaddr,sizeof(toaddr));
	if(send_len == -1)
	{
		perror("send to");
		return send_len;
	}
}






