/*
 * =====================================================================================
 *
 *       Filename:  header.h
 *       Compiler:  g++
 *
 *         Author:  wangbo@corp.netease.com
 *
 *      CopyRight:  Copyright (c) netease
 *
 *    Description:  
 *
 *        Created:  2009-09-10 09:11:08
 * =====================================================================================
 */


#ifndef  _TCP_REDIRECT_HEADER_H__INC
#define  _TCP_REDIRECT_HEADER_H__INC


#define SYN_SEND     1
#define SYN_CONFIRM  2
#define SERVER_FIN  4
#define	CLIENT_FIN  8


#endif   /* ----- #ifndef _HEADER_H__INC  ----- */
