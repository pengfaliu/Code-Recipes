/*
 * =====================================================================================
 *
 *       Filename:  session.cpp
 *       Compiler:  g++
 *
 *         Author:  wangbo@corp.netease.com
 *
 *      CopyRight:  Copyright (c) netease
 *
 *    Description:  
 *
 *        Created:  2009-09-10 14:46:06
 * =====================================================================================
 */

#include <map>
#include <stdio.h>
#include "session.h"
#include "send.h"

using std::map;

uint32_t local_ip;
uint32_t remote_ip;
uint16_t local_port;
uint16_t remote_port;

typedef map<uint64_t,session_st> seContainer;
typedef map<uint64_t,session_st>::iterator seIterator;

static seContainer sessions;

void session_st::send_fake_ack(uint32_t s_ip,uint16_t s_port)
{  
	static unsigned char fake_ack_buf[40];
	memset(fake_ack_buf,40,0);
	struct iphdr *ip_header = (struct iphdr *)fake_ack_buf;
	struct tcphdr *tcp_header = (struct tcphdr *)(fake_ack_buf+20);
	ip_header->version = 4;
	ip_header->ihl = 5;
	ip_header->tot_len = htons(20);
	ip_header->id = htons(client_ip_id+2);
	ip_header->frag_off = 64;
	ip_header->ttl = 64;
	ip_header->protocol = 6;
	ip_header->saddr = s_ip;
	tcp_header->source = s_port;
	tcp_header->seq = client_next_sequence;
	tcp_header->ack = 1;
	tcp_header->window = client_window;
	send_ip_package(fake_ack_buf,virtual_next_sequence);

	confirmed = true;
}
inline uint32_t plus_1(uint32_t seq)
{
	return htonl(ntohl(seq)+1);
}
void session_st::update_virtual_status(struct iphdr *ip_header,struct tcphdr* tcp_header)
{
	if( tcp_header->rst)
	{
		reset_flag = true;
		return;
	}
	if( !(tcp_header->ack))
	{
		return;
	}
	virtual_ack = tcp_header->ack_seq;
	if( tcp_header->syn)
	{
		virtual_next_sequence = plus_1(tcp_header->seq);
		virtual_status |= SYN_CONFIRM;
		confirmed = false;
		while(! unsend.empty())
		{
			unsigned char *data = unsend.front();
			send_ip_package(data,virtual_next_sequence);
			confirmed = true;
			free(data);
			unsend.pop_front();
		}
		return;
	}
	else if(tcp_header->fin)
	{
		virtual_status  |= SERVER_FIN;
		virtual_next_sequence = plus_1(tcp_header->seq);
		confirmed = false;
		if(fin_ack_package)
		{
			send_ip_package(fin_ack_package,virtual_next_sequence);
			confirmed = true;
		}
		return;
	}
	uint32_t tot_len = ntohs(ip_header->tot_len);
	uint32_t next_seq = htonl(ntohl(tcp_header->seq)+tot_len-ip_header->ihl*4-tcp_header->doff*4);
	
	if(ntohl(next_seq) < ntohl(virtual_next_sequence))
	{
		send_fake_ack(ip_header->daddr,tcp_header->dest);
	}
	else if(ntohl(next_seq)==ntohl(virtual_next_sequence))
	{
		//has data
		if(tot_len != ip_header->ihl*4+tcp_header->doff*4)
		{
			confirmed = false;
			send_fake_ack(ip_header->daddr,tcp_header->dest);
		}
	}
	else
	{
		virtual_next_sequence = next_seq;
		confirmed = false;
	}

	//confirm all package
	if(virtual_ack == client_next_sequence)
	{
		if(fin_ack_package)
		{
			send_ip_package(fin_ack_package,virtual_next_sequence);
			virtual_status |= CLIENT_FIN;
			confirmed = true;
		}
	}
}

unsigned char * session_st::copy_ip_package(struct iphdr *ip_header)
{
	uint16_t tot_len = ntohs(ip_header->tot_len);
	unsigned char *data = (unsigned char *)malloc(tot_len);
	if(data)
	{
		memcpy(data,ip_header,tot_len);
	}
	return data;
}

void session_st::save_header_info(struct iphdr *ip_header,struct tcphdr *tcp_header)
{
	uint16_t tot_len = ip_header->tot_len;
	client_next_sequence = htonl(ntohl(tcp_header->seq)+tot_len-ip_header->ihl*4-tcp_header->doff*4);
	client_ip_id = ip_header->id;
	client_window = tcp_header->window;
}

void session_st::process_recv(struct iphdr *ip_header,struct tcphdr *tcp_header)
{
	if(tcp_header->rst)
	{
		send_ip_package((unsigned char *) ip_header,virtual_next_sequence);
		reset_flag = true;
		return;
	}
	//syn package
	if(tcp_header->syn)
	{
		send_ip_package((unsigned char *)ip_header,virtual_next_sequence);
		return;
	}
	//fin package
	if(tcp_header->fin)
	{
		//client send fin first ,and all data acked by server
		if(virtual_ack == tcp_header->seq)
		{
			send_ip_package((unsigned char *)ip_header,virtual_next_sequence);
			confirmed = true;
			virtual_status |= CLIENT_FIN;
			return;
		}
		else
		{
			fin_ack_package = copy_ip_package(ip_header);
		}
		return;
	}
	//data package or third package	
	save_header_info(ip_header,tcp_header);
	if(virtual_status == SYN_SEND)
	{
		unsend.push_back(copy_ip_package(ip_header));
		printf("SYN_SEND push back %d\n",unsend.size());
	}
	else
	{
		send_ip_package((unsigned char *)ip_header,virtual_next_sequence);
		confirmed = true;
	}
}



void delete_session(uint32_t ip,uint16_t port)
{
	seIterator iter = sessions.find(get_ip_port_value(ip,port));
	if(iter != sessions.end())
	{
		sessions.erase(iter);
	}
}


void push_back_data(uint32_t ip,uint16_t port,unsigned char *data)
{
	sessions[get_ip_port_value(ip,port)].unsend.push_back(data);
}


void process(char *packet,int len)
{
	struct etharp_frame *ether = (struct etharp_frame *)packet;
	struct tcphdr *tcp_header;
	struct iphdr *ip_header;
	uint32_t size_ip;
	uint32_t size_tcp;
	
	if(ntohs(ether->type) != 0x800){
		return;
	}
	ip_header = (struct iphdr*)(packet+sizeof(struct etharp_frame ) );
	//check ip header
	if(ip_header->protocol != IPPROTO_TCP)
	{
		return ;
	}
	size_ip = ip_header->ihl*4;
	if (size_ip < 20) {
		printf("   * Invalid IP header length: %u bytes %d\n", size_ip,ip_header->protocol);
		return ;
	}
	tcp_header = (struct tcphdr*)((char *)ip_header+size_ip);
	size_tcp = tcp_header->doff*4;
	if (size_tcp < 20) {
		printf("   * Invalid TCP header length: %u bytes\n", size_tcp);
		return ;
	}

	if( (ip_header->saddr==remote_ip) && (tcp_header->source==remote_port) )
	{
		seIterator iter = sessions.find(get_ip_port_value(ip_header->daddr,tcp_header->dest));
		if(iter != sessions.end())
		{
			iter->second.update_virtual_status(ip_header,tcp_header);
			if( iter->second.is_over())
			{
				sessions.erase(iter);
			}
		}
	}
	else if( (ip_header->daddr==local_ip) && (tcp_header->dest==local_port))
	{
		if(tcp_header->syn)
		{
			sessions[get_ip_port_value(ip_header->saddr,tcp_header->source)].process_recv(ip_header,tcp_header);
		}
		else
		{
			seIterator iter = sessions.find(get_ip_port_value(ip_header->saddr,tcp_header->source));
			if(iter != sessions.end())
			{
				iter->second.process_recv(ip_header,tcp_header);
				if( (iter->second.is_over()))
				{
					sessions.erase(iter);
				}
			}
		}
	}
	else
	{
		return;
	}
	time_t now_time = time(NULL);
	printf("%d   %x:%d-->%x:%d,length %d\n",now_time,htonl(ip_header->saddr),htons(tcp_header->source),htonl(ip_header->daddr),htons(tcp_header->dest),len);
}


